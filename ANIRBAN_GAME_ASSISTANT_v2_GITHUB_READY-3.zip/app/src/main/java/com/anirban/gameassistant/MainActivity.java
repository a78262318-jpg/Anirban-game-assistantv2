package com.anirban.gameassistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.BatteryManager;
import android.content.Context;
import android.view.Gravity;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private ArrayList<MacroStep> steps;
    private ArrayAdapter<MacroStep> adapter;
    private ListView list;
    private EditText x1,y1,x2,y2,delay;
    private Spinner repeat;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        steps=MacroStore.load(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,16,16,16);
        root.setBackgroundColor(0xFF101A14);

        TextView title=new TextView(this);
        title.setText("ANIRBAN GAME ASSISTANT v2.0");
        title.setTextColor(0xFF39E879); title.setTextSize(22); title.setGravity(Gravity.CENTER);
        root.addView(title);

        status=new TextView(this); status.setTextColor(0xFFFFFFFF); root.addView(status); updateInfo();

        LinearLayout row1=new LinearLayout(this);
        x1=field("X"); y1=field("Y"); x2=field("End X"); y2=field("End Y");
        row1.addView(x1); row1.addView(y1); row1.addView(x2); row1.addView(y2); root.addView(row1);

        LinearLayout row2=new LinearLayout(this);
        delay=field("Delay ms"); delay.setText("300"); row2.addView(delay);
        Button tap=button("ADD TAP"); tap.setOnClickListener(v -> addStep(false)); row2.addView(tap);
        Button swipe=button("ADD SWIPE"); swipe.setOnClickListener(v -> addStep(true)); row2.addView(swipe);
        root.addView(row2);

        list=new ListView(this);
        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,steps);
        list.setAdapter(adapter);
        list.setOnItemLongClickListener((p,v,pos,id)->{steps.remove(pos);persist();return true;});
        root.addView(list,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout controls=new LinearLayout(this);
        repeat=new Spinner(this);
        String[] choices={"1x","2x","5x","10x","Infinite"};
        repeat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));
        controls.addView(repeat);
        Button start=button("START"); start.setOnClickListener(v->startMacro()); controls.addView(start);
        Button stop=button("STOP"); stop.setOnClickListener(v->MacroAccessibilityService.stopNow()); controls.addView(stop);
        root.addView(controls);

        LinearLayout permissions=new LinearLayout(this);
        Button access=button("ACCESSIBILITY"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); permissions.addView(access);
        Button overlay=button("OVERLAY"); overlay.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())))); permissions.addView(overlay);
        Button bubble=button("FLOATING"); bubble.setOnClickListener(v->{
            if(Settings.canDrawOverlays(this)) startService(new Intent(this,FloatingService.class));
            else Toast.makeText(this,"আগে OVERLAY permission দাও",Toast.LENGTH_LONG).show();
        }); permissions.addView(bubble);
        root.addView(permissions);
        Button clear=button("CLEAR ALL STEPS"); clear.setOnClickListener(v->{steps.clear();persist();}); root.addView(clear);

        TextView help=new TextView(this);
        help.setTextColor(0xFFDDDDDD);
        help.setText("Tap: X/Y ব্যবহার করো। Swipe: X/Y ও End X/End Y দাও। List item long-press করলে মুছবে। Coordinate হলো screen pixel।");
        root.addView(help);
        setContentView(root);
    }

    private EditText field(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setHintTextColor(0xFFAAAAAA); e.setTextColor(0xFFFFFFFF);
        e.setEms(3); return e;
    }
    private Button button(String text) { Button b=new Button(this); b.setText(text); return b; }
    private float val(EditText e) { try{return Float.parseFloat(e.getText().toString().trim());}catch(Exception ex){return -1;} }
    private void addStep(boolean swipe) {
        float a=val(x1), b=val(y1), c=swipe?val(x2):a, d=swipe?val(y2):b;
        long wait; try{wait=Long.parseLong(delay.getText().toString());}catch(Exception e){wait=300;}
        if(a<0||b<0||c<0||d<0) { Toast.makeText(this,"সঠিক coordinate দাও",Toast.LENGTH_SHORT).show(); return; }
        steps.add(new MacroStep(swipe?"SWIPE":"TAP",a,b,c,d,Math.max(0,wait)));
        persist();
    }
    private void persist() { MacroStore.save(this,steps); adapter.notifyDataSetChanged(); }
    private void startMacro() {
        if(!MacroAccessibilityService.isReady()) {
            Toast.makeText(this,"আগে Accessibility Service চালু করো",Toast.LENGTH_LONG).show(); return;
        }
        int pos=repeat.getSelectedItemPosition();
        int count=pos==4?-1:(pos==0?1:(pos==1?2:(pos==2?5:10)));
        MacroAccessibilityService.runSteps(new ArrayList<>(steps),count);
        Toast.makeText(this,"Macro started",Toast.LENGTH_SHORT).show();
    }
    private void updateInfo() {
        BatteryManager bm=(BatteryManager)getSystemService(Context.BATTERY_SERVICE);
        int level=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        status.setText("Battery: "+level+"%  |  Device: "+android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL+
            "  |  Screen: "+getResources().getDisplayMetrics().widthPixels+"x"+getResources().getDisplayMetrics().heightPixels);
    }
}
