package com.anirban.gameassistant;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;

public class MacroStore {
    private static final String PREF="anirban_macro_store", KEY="steps";
    public static void save(Context c, ArrayList<MacroStep> steps) {
        JSONArray a=new JSONArray();
        try { for (MacroStep s:steps) a.put(s.toJson()); }
        catch (JSONException e) { return; }
        prefs(c).edit().putString(KEY,a.toString()).apply();
    }
    public static ArrayList<MacroStep> load(Context c) {
        ArrayList<MacroStep> out=new ArrayList<>();
        try {
            JSONArray a=new JSONArray(prefs(c).getString(KEY,"[]"));
            for(int i=0;i<a.length();i++) out.add(MacroStep.fromJson(a.getJSONObject(i)));
        } catch(Exception ignored) {}
        return out;
    }
    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
    }
}
