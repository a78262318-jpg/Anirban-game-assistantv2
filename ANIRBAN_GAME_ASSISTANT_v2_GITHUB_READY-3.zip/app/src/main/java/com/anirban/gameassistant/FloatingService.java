package com.anirban.gameassistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FloatingService extends Service {
    private WindowManager wm;
    private LinearLayout panel;
    @Override public void onCreate() {
        super.onCreate();
        if(!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(8,8,8,8);
        panel.setBackgroundColor(0xEE17251D);
        Button title=new Button(this); title.setText("ANIRBAN • MACRO"); panel.addView(title);
        Button open=new Button(this); open.setText("OPEN APP");
        open.setOnClickListener(v -> {
            Intent i=new Intent(this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        }); panel.addView(open);
        Button stop=new Button(this); stop.setText("STOP MACRO");
        stop.setOnClickListener(v -> MacroAccessibilityService.stopNow()); panel.addView(stop);
        Button close=new Button(this); close.setText("CLOSE BUBBLE");
        close.setOnClickListener(v -> stopSelf()); panel.addView(close);
        int type=Build.VERSION.SDK_INT>=26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.RIGHT; lp.x=20; lp.y=180;
        try { wm.addView(panel,lp); } catch(Exception e) { Toast.makeText(this,"Overlay permission needed",Toast.LENGTH_LONG).show(); stopSelf(); }
    }
    @Override public void onDestroy() { if(wm!=null && panel!=null) try{wm.removeView(panel);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
