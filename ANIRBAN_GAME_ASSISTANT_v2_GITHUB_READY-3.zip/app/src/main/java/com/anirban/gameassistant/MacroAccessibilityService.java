package com.anirban.gameassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class MacroAccessibilityService extends AccessibilityService {
    private static MacroAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private volatile boolean running=false;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopMacro(); }
    @Override public void onDestroy() { stopMacro(); if(instance==this) instance=null; super.onDestroy(); }

    public static boolean isReady() { return instance!=null; }
    public static void runSteps(java.util.ArrayList<MacroStep> steps, int repeats) {
        if(instance!=null) instance.startMacro(steps,repeats);
    }
    public static void stopNow() { if(instance!=null) instance.stopMacro(); }

    private void startMacro(java.util.ArrayList<MacroStep> steps, int repeats) {
        stopMacro();
        if(steps==null || steps.isEmpty()) return;
        running=true;
        final int total = repeats < 0 ? Integer.MAX_VALUE : Math.max(1,repeats);
        playStep(steps,0,0,total);
    }
    private void playStep(java.util.ArrayList<MacroStep> steps,int index,int loop,int total) {
        if(!running) return;
        if(index>=steps.size()) {
            if(loop+1>=total) { running=false; return; }
            playStep(steps,0,loop+1,total); return;
        }
        MacroStep s=steps.get(index);
        handler.postDelayed(() -> {
            if(!running) return;
            Path p=new Path(); p.moveTo(s.x1,s.y1);
            long duration=1;
            if("SWIPE".equals(s.type)) { p.lineTo(s.x2,s.y2); duration=450; }
            GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,duration);
            dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),
                new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) {
                        playStep(steps,index+1,loop,total);
                    }
                    @Override public void onCancelled(GestureDescription g) {
                        if(running) playStep(steps,index+1,loop,total);
                    }
                }, handler);
        }, Math.max(0,s.delay));
    }
    private void stopMacro() { running=false; handler.removeCallbacksAndMessages(null); }
}
