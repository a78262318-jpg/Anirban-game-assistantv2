package com.anirban.gameassistant;

import org.json.JSONException;
import org.json.JSONObject;

public class MacroStep {
    public String type;
    public float x1, y1, x2, y2;
    public long delay;

    public MacroStep(String type, float x1, float y1, float x2, float y2, long delay) {
        this.type=type; this.x1=x1; this.y1=y1; this.x2=x2; this.y2=y2; this.delay=delay;
    }
    public JSONObject toJson() throws JSONException {
        JSONObject o=new JSONObject();
        o.put("type",type); o.put("x1",x1); o.put("y1",y1);
        o.put("x2",x2); o.put("y2",y2); o.put("delay",delay);
        return o;
    }
    public static MacroStep fromJson(JSONObject o) throws JSONException {
        return new MacroStep(o.getString("type"), (float)o.getDouble("x1"),
            (float)o.getDouble("y1"), (float)o.getDouble("x2"),
            (float)o.getDouble("y2"), o.getLong("delay"));
    }
    @Override public String toString() {
        if ("TAP".equals(type)) return "TAP ("+(int)x1+", "+(int)y1+") • "+delay+"ms";
        return "SWIPE ("+(int)x1+", "+(int)y1+") → ("+(int)x2+", "+(int)y2+") • "+delay+"ms";
    }
}
