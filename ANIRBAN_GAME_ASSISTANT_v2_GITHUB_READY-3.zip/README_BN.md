# ANIRBAN GAME ASSISTANT v2.0

এটি GitHub Actions দিয়ে Android Debug APK বানানোর জন্য একটি Android Studio/Gradle project।

## v2.0-তে বাস্তবায়িত
- Macro step editor: Tap ও Swipe/Drag step যোগ করা
- Macro list: step যোগ/মুছা/সব মুছা
- Repeat: 1x, 2x, 5x, 10x ও infinite
- Speed/delay control (প্রতি step-এর delay)
- Start/Stop macro
- Floating bubble এবং floating control panel
- Accessibility gesture dispatch
- Battery ও device information
- Macro data স্থানীয় SharedPreferences-এ save

## গুরুত্বপূর্ণ সীমাবদ্ধতা
Android সাধারণত অন্য অ্যাপের সব raw touch event গোপনে record করতে দেয় না। তাই এই অ্যাপটি gameplay touch নিজে থেকে record করার দাবি করে না। তুমি Tap/Swipe-এর screen coordinate দিয়ে macro তৈরি করবে। Accessibility Service চালু থাকা এবং Android-এর gesture dispatch অনুমোদিত থাকা দরকার। কিছু গেম/ডিভাইস/Android সংস্করণে gesture কাজ নাও করতে পারে। কোনো aim-bot, anti-cheat bypass বা সুরক্ষা এড়ানোর ব্যবস্থা নেই। অনলাইন গেমের নিয়ম মেনে ব্যবহার করো।

## GitHub থেকে APK বানানো (ফোন দিয়েও)
1. GitHub-এ `ANIRBAN-GAME-ASSISTANT` নামে New repository তৈরি করো।
2. ZIP extract করে **ভেতরের সব ফাইল ও `.github` folder** repository-তে upload করো।
3. GitHub repository → Actions → `Build Android APK` → Run workflow।
4. Build successful হলে Actions run খুলে Artifacts থেকে `ANIRBAN-Game-Assistant-debug-apk` download করো।
5. Artifact ZIP extract করলে `app-debug.apk` পাবে।

Push/commit করলেও workflow স্বয়ংক্রিয়ভাবে চলবে।

## ইনস্টল ও প্রথমবার চালু
1. APK install করে app খুলবে।
2. `Accessibility Settings` চাপো → Downloaded/Installed services-এ ANIRBAN GAME ASSISTANT চালু করো।
3. Floating bubble চাইলে `Overlay Permission` দাও।
4. অ্যাপে Tap/Swipe step তৈরি করো, repeat নির্বাচন করো, Start চাপো।
5. Stop দিয়ে যেকোনো সময় বন্ধ করতে পারবে।

## Coordinate কীভাবে দেবে
ফোনের স্ক্রিনের pixel coordinate ব্যবহার করো। সাধারণত (0,0) হলো স্ক্রিনের ওপরের-বাঁ দিক। Tap-এর জন্য X/Y দাও। Swipe-এর জন্য start X/Y ও end X/Y দাও। ভুল coordinate দিলে ভুল জায়গায় gesture হতে পারে; আগে নিজের test screen-এ পরীক্ষা করো।

## Local build
JDK 17, Android SDK Platform 35, Build Tools 35.0.0 এবং Gradle 8.9:
```bash
gradle --no-daemon assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`
